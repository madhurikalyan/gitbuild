$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"45722b24-83fd-4431-b367-02b089cef453","feature":"Renew Fleet feature","scenario":"IRP Renew fleet","start":1662390679172,"group":1,"content":"","tags":"","end":1662390679597,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});