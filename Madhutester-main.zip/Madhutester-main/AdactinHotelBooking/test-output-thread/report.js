$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "4139a539-69b8-40d4-ad30-975e38de2da3",
    "feature": "Search Hotel From Excel Reader",
    "scenario": "Selecting Hotel",
    "start": 1655193456991,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1655193481865,
    "className": "passed"
  },
  {
    "id": "a5da7359-a1a2-46fa-adb7-244ed9db0045",
    "feature": "Login Page Feature",
    "scenario": "login page",
    "start": 1655193440498,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1655193456938,
    "className": "passed"
  },
  {
    "id": "6c6378b5-f18e-4445-89ce-07e13e6e170f",
    "feature": "Payment Method Page Feature from JSON File",
    "scenario": "Adding Payment Method",
    "start": 1655193481891,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1655193508849,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});